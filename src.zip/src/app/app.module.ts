import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { Routes, RouterModule } from "@angular/router";

// material
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatIconModule } from "@angular/material/icon";
import { MatListModule } from "@angular/material/list";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatButtonModule } from "@angular/material/button";

// components
import { AppComponent } from "./app.component";
import { CourseComponent } from "./pages/course.component";
import { SidenavComponent } from "./sidenav/sidenav.component";
import {BooksComponent} from "./pages/books/books.component";
import {HttpClientModule} from "@angular/common/http";
import {MatCardModule} from "@angular/material/card";
import {TestFilterPipe} from "./pipes/filterPipe";
import {FormsModule} from "@angular/forms";

export const ROUTES: Routes = [

  { path: "**", redirectTo: "BooksComponent" },
  {
    path: "books",
    component: BooksComponent,
  },
  {
    path: "courses",
    component: CourseComponent,
  }
];

@NgModule({
  declarations: [
    AppComponent,
    CourseComponent,
    SidenavComponent,
    BooksComponent,
    TestFilterPipe
  ],
  imports: [
    RouterModule.forRoot(ROUTES),
    BrowserModule,
    BrowserAnimationsModule,
    MatSidenavModule,
    MatListModule,
    MatIconModule,
    MatTooltipModule,
    MatButtonModule,
    HttpClientModule,
    MatCardModule,
    FormsModule
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}

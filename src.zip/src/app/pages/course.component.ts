import { Component } from "@angular/core";

@Component({
  selector: "courses",
  template: ` <p>Course Page</p> `,
  styles: [],
})
export class CourseComponent { }

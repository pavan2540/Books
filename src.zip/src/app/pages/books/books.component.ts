import {Component, OnDestroy, OnInit} from "@angular/core";
import {AppService} from "../../app.service";
import {Subscription} from "rxjs";

@Component({
    selector: "books",
    templateUrl: './books.component.html',
    styleUrls: ['books.component.scss'],
})
export class BooksComponent implements OnInit, OnDestroy {

    products = [];
    searchItem = '';
    subscription: Subscription;

    constructor(private appService: AppService) {
    }

    ngOnInit(): void {
        this.subscription = this.appService.getBooks()
            .subscribe((data: any) => {
                this.products = data.items;
            })
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}

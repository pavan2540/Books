import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
  selector: "side-nav",
  styleUrls: ["./sidenav.component.scss"],
  template: `
    <section [class.sidenav]="isExpanded">
      <div class="toggle" (click)="toggleMenu.emit(null)">
        <mat-icon>
          {{ isExpanded ? "menu" : "dehaze" }}
        </mat-icon>
        <span class="menu-label" matLine *ngIf="isExpanded">Menu</span>
      </div>

      <mat-list class="nav" *ngFor="let route of routeLinks">
        <a
          mat-list-item
          routerLinkActive="active-link"
          class="hover"
          routerLink="{{ route.link }}"
          [routerLinkActiveOptions]="{exact:
true}"
        >
          <mat-icon
            mat-list-icon
            [matTooltip]="!isExpanded ? route.name : null"
            matTooltipPosition="right"
          >
            {{ route.icon }}</mat-icon
          >
          <p matLine *ngIf="isExpanded">{{ route.name }}</p>
        </a>
      </mat-list>
    </section>
  `,
})
export class SidenavComponent {
  @Input() isExpanded: boolean;
  @Output() toggleMenu = new EventEmitter();

  public routeLinks = [
    { link: "books", name: "CONTENT MANAGEMENT", icon: "content_paste_search" },
    { link: "courses", name: "COURSES", icon: "library_books" },
  ];
}
